"use strict";
(() => {
  // packages/shared/src/constants.ts
  var storageKeys = {
    pets: "openpet.pets",
    builtinPetsSeedVersion: "openpet.builtinPetsSeedVersion",
    sitePetBindings: "openpet.sitePetBindings",
    sitePetVisibility: "openpet.sitePetVisibility",
    overlayVisible: "openpet.overlayVisible",
    overlayPlacements: "openpet.overlayPlacements",
    petSizes: "openpet.petSizes",
    animationSpeed: "openpet.animationSpeed",
    popupLocale: "openpet.popupLocale"
  };
  var overlayRootId = "openpet-overlay-root";
  var defaultPetSize = 96;
  var minPetSize = 72;
  var maxPetSize = 192;
  var defaultAnimationSpeed = 1;
  var minAnimationSpeed = 0.5;
  var maxAnimationSpeed = 2;

  // packages/shared/src/messages.ts
  var messageTypes = {
    pageSignals: "openpet/page-signals",
    stateUpdate: "openpet/state-update",
    sceneUpdate: "openpet/scene-update",
    focusTab: "openpet/focus-tab",
    importPet: "openpet/import-pet",
    batchImportPets: "openpet/batch-import-pets",
    setAnimationSpeed: "openpet/set-animation-speed",
    setSitePetBinding: "openpet/set-site-pet-binding",
    setSitePetVisibility: "openpet/set-site-pet-visibility",
    deletePets: "openpet/delete-pets",
    clearPets: "openpet/clear-pets",
    toggleOverlay: "openpet/toggle-overlay",
    popupSnapshot: "openpet/popup-snapshot",
    currentSceneState: "openpet/current-scene-state"
  };

  // apps/chrome-extension/src/overlay/renderOverlay.ts
  var cellWidth = 96;
  var cellHeight = 104;
  var atlasColumns = 8;
  var atlasRows = 9;
  var emptyBackground = "linear-gradient(180deg, rgba(92, 68, 43, 0.08), rgba(92, 68, 43, 0.18))";
  var actionAnimations = {
    idle: { row: 0, frames: [0, 1, 2, 3, 4, 5], durations: [280, 110, 110, 140, 140, 320], loop: true },
    "running-right": { row: 1, frames: [0, 1, 2, 3, 4, 5, 6, 7], durations: [90, 90, 90, 90, 90, 90, 90, 120], loop: true },
    "running-left": { row: 2, frames: [0, 1, 2, 3, 4, 5, 6, 7], durations: [90, 90, 90, 90, 90, 90, 90, 120], loop: true },
    waving: { row: 3, frames: [0, 1, 2, 3], durations: [140, 140, 140, 280], loop: false, fallbackAction: "idle" },
    jumping: { row: 4, frames: [0, 1, 2, 3, 4], durations: [120, 120, 120, 120, 220], loop: false, fallbackAction: "idle" },
    failed: { row: 5, frames: [0, 1, 2, 3, 4, 5, 6, 7], durations: [140, 140, 140, 140, 140, 140, 140, 240], loop: true },
    waiting: { row: 6, frames: [0, 1, 2, 3, 4, 5], durations: [150, 150, 150, 150, 150, 260], loop: true },
    running: { row: 7, frames: [0, 1, 2, 3, 4, 5], durations: [120, 120, 120, 120, 120, 220], loop: true },
    review: { row: 8, frames: [0, 1, 2, 3, 4, 5], durations: [150, 150, 150, 150, 150, 280], loop: true }
  };
  var businessStateToAction = {
    idle: "idle",
    streaming: "running",
    waiting: "waiting",
    error: "failed",
    done: "waving"
  };
  var latestMessage = null;
  var latestAnimationSpeed = defaultAnimationSpeed;
  var animationTimerMap = /* @__PURE__ */ new WeakMap();
  var animationTokenMap = /* @__PURE__ */ new WeakMap();
  var optimisticPlacementMap = /* @__PURE__ */ new Map();
  var optimisticSizeMap = /* @__PURE__ */ new Map();
  var overlayStyles = `
#${overlayRootId} {
  position: fixed;
  inset: 0;
  padding: 0;
  border: 0;
  background: transparent;
  box-shadow: none;
  z-index: 2147483647;
  font-family: Inter, "Segoe UI", sans-serif;
  color: #3b2b22;
  pointer-events: none;
}
#${overlayRootId}[data-hidden="true"] { display: none; }
#${overlayRootId} .openpet-scene {
  position: relative;
  width: 100%;
  height: 100%;
}
#${overlayRootId} button {
  all: unset;
  position: absolute;
  cursor: default;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  pointer-events: auto;
  user-select: none;
  touch-action: none;
}
#${overlayRootId} .openpet-sprite {
  width: ${defaultPetSize}px;
  height: ${defaultPetSize * cellHeight / cellWidth}px;
  display: block;
  margin: 0;
  image-rendering: auto;
  background-repeat: no-repeat;
  background-position: 0 0;
  background-size: ${defaultPetSize * atlasColumns}px ${defaultPetSize * atlasRows * cellHeight / cellWidth}px;
}
#${overlayRootId} .openpet-state {
  font-size: 12px;
  text-align: center;
  padding: 2px 6px;
  border-radius: 999px;
  background: rgba(247, 241, 232, 0.88);
  line-height: 1.2;
}
#${overlayRootId} .openpet-resize-handle {
  position: absolute;
  right: -6px;
  bottom: 20px;
  width: 18px;
  height: 18px;
  cursor: nwse-resize;
  border-radius: 999px;
  background: rgba(255, 253, 249, 0.96);
  border: 1px solid rgba(109, 78, 53, 0.28);
  box-shadow: 0 4px 10px rgba(84, 60, 41, 0.16);
  opacity: 0;
  pointer-events: none;
}
#${overlayRootId} .openpet-resize-handle::before {
  content: "";
  position: absolute;
  inset: 4px;
  border-right: 2px solid rgba(109, 78, 53, 0.7);
  border-bottom: 2px solid rgba(109, 78, 53, 0.7);
}
#${overlayRootId} button[data-handle-visible="true"] .openpet-resize-handle {
  opacity: 1;
  pointer-events: auto;
}
#${overlayRootId} .openpet-context-menu {
  position: absolute;
  min-width: 108px;
  padding: 6px;
  border-radius: 12px;
  background: rgba(255, 253, 249, 0.98);
  border: 1px solid rgba(109, 78, 53, 0.16);
  box-shadow: 0 12px 24px rgba(84, 60, 41, 0.18);
  pointer-events: auto;
}
#${overlayRootId} .openpet-context-menu button {
  all: unset;
  display: block;
  width: 100%;
  box-sizing: border-box;
  padding: 8px 10px;
  border-radius: 10px;
  cursor: pointer;
  font-size: 12px;
}
`;
  function getStorageArea() {
    return globalThis.chrome?.storage?.local ?? null;
  }
  function ensureRoot() {
    let root = document.getElementById(overlayRootId);
    if (!root) {
      root = document.createElement("div");
      root.id = overlayRootId;
      document.documentElement.appendChild(root);
    }
    let style = root.querySelector("style");
    if (!style) {
      style = document.createElement("style");
      root.prepend(style);
    }
    style.textContent = overlayStyles;
    if (!root.querySelector(".openpet-scene")) {
      const scene = document.createElement("div");
      scene.className = "openpet-scene";
      root.append(scene);
    }
    bindPlacementSync(root);
    return root;
  }
  function bindPlacementSync(root) {
    if (root.dataset.placementBound === "true") {
      return;
    }
    root.dataset.placementBound = "true";
    const storageArea = getStorageArea();
    if (!storageArea) {
      return;
    }
    globalThis.chrome?.storage?.onChanged?.addListener((changes, areaName) => {
      if (areaName !== "local" || !(storageKeys.overlayPlacements in changes) && !(storageKeys.petSizes in changes)) {
        return;
      }
      if (latestMessage) {
        applyOverlayUpdate(latestMessage);
      }
    });
  }
  function setSpriteFrame(sprite, action, frameIndex, petSize) {
    const animation = actionAnimations[action];
    const column = animation.frames[frameIndex] ?? 0;
    const scaledCellHeight = petSize * (cellHeight / cellWidth);
    sprite.dataset.action = action;
    sprite.dataset.frame = String(column);
    sprite.style.backgroundPosition = `${-column * petSize}px ${-animation.row * scaledCellHeight}px`;
  }
  function syncSpriteDimensions(sprite, petSize) {
    const petHeight = petSize * cellHeight / cellWidth;
    sprite.style.width = `${petSize}px`;
    sprite.style.height = `${petHeight}px`;
    sprite.style.backgroundSize = `${petSize * atlasColumns}px ${petHeight * atlasRows}px`;
  }
  function syncCurrentSpriteFrame(sprite, petSize) {
    const action = sprite.dataset.action;
    const frameColumn = Number.parseInt(sprite.dataset.frame ?? "", 10);
    if (!action || Number.isNaN(frameColumn)) {
      return;
    }
    const animation = actionAnimations[action];
    const frameIndex = animation.frames.indexOf(frameColumn);
    const resolvedFrameIndex = frameIndex >= 0 ? frameIndex : 0;
    setSpriteFrame(sprite, action, resolvedFrameIndex, petSize);
  }
  function shouldRepeatTransientAction(sprite, action) {
    if (action !== "jumping") {
      return false;
    }
    const button = sprite.closest("button");
    return button?.__openPetHovering === true;
  }
  function clearSpriteAnimation(sprite) {
    const existing = animationTimerMap.get(sprite);
    if (existing !== void 0) {
      window.clearTimeout(existing);
      animationTimerMap.delete(sprite);
    }
  }
  function resolveAnimationSpeed(speed) {
    if (!Number.isFinite(speed)) {
      return defaultAnimationSpeed;
    }
    return Math.max(minAnimationSpeed, Math.min(maxAnimationSpeed, speed));
  }
  function startSpriteAnimation(sprite, petState, action, petSize) {
    if (!petState.pet.spritesheetDataUrl) {
      clearSpriteAnimation(sprite);
      sprite.style.backgroundImage = emptyBackground;
      sprite.removeAttribute("data-action");
      sprite.removeAttribute("data-frame");
      delete sprite.dataset.sourceUrl;
      return;
    }
    if (sprite.dataset.action === action && sprite.dataset.sourceUrl === petState.pet.spritesheetDataUrl && animationTimerMap.has(sprite)) {
      return;
    }
    clearSpriteAnimation(sprite);
    sprite.style.backgroundImage = `url("${petState.pet.spritesheetDataUrl}")`;
    sprite.dataset.sourceUrl = petState.pet.spritesheetDataUrl;
    const token = (animationTokenMap.get(sprite) ?? 0) + 1;
    animationTokenMap.set(sprite, token);
    const tick = (frameIndex, currentAction) => {
      if (token !== animationTokenMap.get(sprite)) {
        return;
      }
      const currentAnimation = actionAnimations[currentAction];
      setSpriteFrame(sprite, currentAction, frameIndex, petSize);
      const isLastFrame = frameIndex >= currentAnimation.frames.length - 1;
      if (isLastFrame && !currentAnimation.loop) {
        const fallbackAction = shouldRepeatTransientAction(sprite, currentAction) ? currentAction : currentAnimation.fallbackAction ?? "idle";
        const timer2 = window.setTimeout(
          () => tick(0, fallbackAction),
          Math.round((currentAnimation.durations[frameIndex] ?? 180) / resolveAnimationSpeed(latestAnimationSpeed))
        );
        animationTimerMap.set(sprite, timer2);
        return;
      }
      const nextFrameIndex = (frameIndex + 1) % currentAnimation.frames.length;
      const timer = window.setTimeout(
        () => tick(nextFrameIndex, currentAction),
        Math.round(
          (currentAnimation.durations[frameIndex] ?? currentAnimation.durations[0]) / resolveAnimationSpeed(latestAnimationSpeed)
        )
      );
      animationTimerMap.set(sprite, timer);
    };
    tick(0, action);
  }
  function resolvePlacement(petState) {
    const optimisticPlacement = optimisticPlacementMap.get(petState.petId);
    if (optimisticPlacement && optimisticPlacement.left === petState.placement.left && optimisticPlacement.top === petState.placement.top && optimisticPlacement.facing === petState.placement.facing) {
      optimisticPlacementMap.delete(petState.petId);
      return petState.placement;
    }
    return optimisticPlacement ?? petState.placement;
  }
  function resolveDisplayedAction(button, petState) {
    if (button.__openPetDragAction) {
      return button.__openPetDragAction;
    }
    if (button.__openPetHovering) {
      return "jumping";
    }
    return businessStateToAction[petState.state];
  }
  function refreshPetPresentation(button, petState) {
    button.__openPetState = petState;
    const placement = resolvePlacement(petState);
    const petSize = resolvePetSize(petState);
    button.style.left = `${placement.left}px`;
    button.style.top = `${placement.top}px`;
    petState.size = petSize;
    const sprite = button.querySelector(".openpet-sprite");
    const label = button.querySelector(".openpet-state");
    if (sprite) {
      syncSpriteDimensions(sprite, petSize);
      startSpriteAnimation(sprite, petState, resolveDisplayedAction(button, petState), petSize);
    }
    if (label) {
      label.textContent = petState.state;
    }
  }
  async function persistSize(siteId, size) {
    const storageArea = getStorageArea();
    if (!storageArea) {
      return;
    }
    const result = await storageArea.get(storageKeys.petSizes);
    const sizes = result[storageKeys.petSizes] && typeof result[storageKeys.petSizes] === "object" ? result[storageKeys.petSizes] : {};
    await storageArea.set({
      [storageKeys.petSizes]: {
        ...sizes,
        [siteId]: size
      }
    });
  }
  function clampSize(size) {
    return Math.max(minPetSize, Math.min(maxPetSize, size));
  }
  function resolvePetSize(petState) {
    const optimisticSize = optimisticSizeMap.get(petState.petId);
    const nextSize = clampSize(
      typeof petState.size === "number" && Number.isFinite(petState.size) ? petState.size : defaultPetSize
    );
    if (optimisticSize !== void 0 && optimisticSize === nextSize) {
      optimisticSizeMap.delete(petState.petId);
      return nextSize;
    }
    return optimisticSize ?? nextSize;
  }
  function hideContextMenu(root) {
    root.querySelector(".openpet-context-menu")?.remove();
  }
  function showContextMenu(button, event, petState) {
    const root = ensureRoot();
    hideContextMenu(root);
    const menu = document.createElement("div");
    menu.className = "openpet-context-menu";
    menu.style.left = `${event.clientX}px`;
    menu.style.top = `${event.clientY}px`;
    menu.innerHTML = `<button type="button" data-menu-action="close-pet">\u5173\u95ED\u5BA0\u7269</button>`;
    root.append(menu);
    menu.querySelector("[data-menu-action='close-pet']")?.addEventListener("click", () => {
      void chrome.runtime.sendMessage({
        type: messageTypes.setSitePetVisibility,
        payload: { siteId: petState.siteId, visible: false }
      });
      hideContextMenu(root);
    });
    window.setTimeout(() => {
      const dismiss = () => {
        hideContextMenu(root);
        document.removeEventListener("pointerdown", dismiss, true);
      };
      document.addEventListener("pointerdown", dismiss, true);
    }, 0);
  }
  async function persistPlacement(siteId, placement) {
    const storageArea = getStorageArea();
    if (!storageArea) {
      return;
    }
    const result = await storageArea.get(storageKeys.overlayPlacements);
    const placements = result[storageKeys.overlayPlacements] && typeof result[storageKeys.overlayPlacements] === "object" ? result[storageKeys.overlayPlacements] : {};
    await storageArea.set({
      [storageKeys.overlayPlacements]: {
        ...placements,
        [siteId]: placement
      }
    });
  }
  function bindPetInteractions(button, petState) {
    button.onclick = () => {
      if (button.dataset.suppressClick === "true") {
        button.dataset.suppressClick = "false";
        return;
      }
      const message = {
        type: messageTypes.focusTab,
        payload: { tabId: petState.tabId }
      };
      void chrome.runtime.sendMessage(message);
    };
    button.onpointerdown = (event) => {
      if (button.__openPetResizing) {
        return;
      }
      if (event.button !== 0) {
        return;
      }
      event.preventDefault();
      const rect = button.getBoundingClientRect();
      button.style.left = `${rect.left}px`;
      button.style.top = `${rect.top}px`;
      button.__openPetDragState = {
        pointerId: event.pointerId,
        startX: event.clientX,
        startY: event.clientY,
        lastX: event.clientX,
        originLeft: rect.left,
        originTop: rect.top,
        moved: false
      };
      button.style.cursor = "grabbing";
      button.setPointerCapture?.(event.pointerId);
    };
    button.onpointermove = (event) => {
      const dragState = button.__openPetDragState;
      if (!dragState || dragState.pointerId !== event.pointerId) {
        return;
      }
      const deltaX = event.clientX - dragState.startX;
      const deltaY = event.clientY - dragState.startY;
      if (!dragState.moved && Math.hypot(deltaX, deltaY) < 6) {
        return;
      }
      dragState.moved = true;
      const moveDeltaX = event.clientX - dragState.lastX;
      const nextPlacement = {
        left: Math.max(0, dragState.originLeft + deltaX),
        top: Math.max(0, dragState.originTop + deltaY),
        facing: petState.placement.facing
      };
      optimisticPlacementMap.set(petState.petId, nextPlacement);
      if (moveDeltaX !== 0) {
        button.__openPetDragAction = moveDeltaX > 0 ? "running-right" : "running-left";
      }
      dragState.lastX = event.clientX;
      button.style.left = `${nextPlacement.left}px`;
      button.style.top = `${nextPlacement.top}px`;
      refreshPetPresentation(button, petState);
    };
    const finishDrag = (event) => {
      const dragState = button.__openPetDragState;
      if (!dragState || dragState.pointerId !== event.pointerId) {
        return;
      }
      delete button.__openPetDragState;
      if (dragState.moved) {
        button.dataset.suppressClick = "true";
        button.__openPetDragAction = null;
        button.style.cursor = "default";
        refreshPetPresentation(button, petState);
        const placement = optimisticPlacementMap.get(petState.petId) ?? petState.placement;
        void persistPlacement(petState.siteId, {
          left: placement.left,
          top: placement.top,
          facing: placement.facing
        });
        return;
      }
      button.__openPetDragAction = null;
      button.style.cursor = "default";
      refreshPetPresentation(button, petState);
    };
    button.onpointerup = finishDrag;
    button.onpointercancel = finishDrag;
    button.onpointerenter = () => {
      button.__openPetHovering = true;
      button.dataset.handleVisible = "true";
      const resizeHandle = button.querySelector(".openpet-resize-handle");
      if (resizeHandle) {
        resizeHandle.dataset.visible = "true";
      }
      refreshPetPresentation(button, petState);
    };
    button.onpointerleave = () => {
      button.__openPetHovering = false;
      button.__openPetDragAction = null;
      if (!button.__openPetResizing) {
        button.dataset.handleVisible = "false";
        const resizeHandle = button.querySelector(".openpet-resize-handle");
        if (resizeHandle) {
          resizeHandle.dataset.visible = "false";
        }
      }
      refreshPetPresentation(button, petState);
    };
    button.oncontextmenu = (event) => {
      event.preventDefault();
      showContextMenu(button, event, petState);
    };
    const handle = button.querySelector(".openpet-resize-handle");
    if (!handle) {
      return;
    }
    handle.dataset.visible = button.dataset.handleVisible === "true" ? "true" : "false";
    handle.onpointerdown = (event) => {
      if (event.button !== 0) {
        return;
      }
      event.preventDefault();
      event.stopPropagation();
      button.__openPetResizing = true;
      button.dataset.handleVisible = "true";
      handle.dataset.visible = "true";
      handle.__openPetResizeState = {
        pointerId: event.pointerId,
        originSize: resolvePetSize(petState),
        startX: event.clientX,
        startY: event.clientY
      };
      handle.setPointerCapture?.(event.pointerId);
    };
    handle.onpointermove = (event) => {
      const resizeState = handle.__openPetResizeState;
      if (!resizeState || resizeState.pointerId !== event.pointerId) {
        return;
      }
      const delta = Math.max(event.clientX - resizeState.startX, event.clientY - resizeState.startY);
      const nextSize = clampSize(resizeState.originSize + delta);
      petState.size = nextSize;
      const sprite = button.querySelector(".openpet-sprite");
      if (sprite) {
        syncSpriteDimensions(sprite, nextSize);
        syncCurrentSpriteFrame(sprite, nextSize);
      }
    };
    const finishResize = (event) => {
      const resizeState = handle.__openPetResizeState;
      if (!resizeState || resizeState.pointerId !== event.pointerId) {
        return;
      }
      delete handle.__openPetResizeState;
      button.__openPetResizing = false;
      petState.size = clampSize(
        Number.parseFloat(button.querySelector(".openpet-sprite")?.style.width ?? "") || resolvePetSize(petState)
      );
      optimisticSizeMap.set(petState.petId, petState.size);
      handle.dataset.visible = button.dataset.handleVisible === "true" ? "true" : "false";
      void persistSize(petState.siteId, petState.size);
    };
    handle.onpointerup = finishResize;
    handle.onpointercancel = finishResize;
  }
  function renderPet(scene, petState) {
    if (optimisticSizeMap.has(petState.petId)) {
      petState.size = optimisticSizeMap.get(petState.petId);
    }
    let button = scene.querySelector(
      `button[data-pet-id="${petState.petId}"]`
    );
    if (!button) {
      button = document.createElement("button");
      button.type = "button";
      button.className = "openpet-button";
      button.dataset.petId = petState.petId;
      button.dataset.handleVisible = "false";
      button.innerHTML = `<div class="openpet-sprite" aria-hidden="true"></div><div class="openpet-state"></div><div class="openpet-resize-handle" data-resize-handle="true" data-visible="false"></div>`;
      scene.append(button);
    }
    button.dataset.siteId = petState.siteId;
    bindPetInteractions(button, petState);
    refreshPetPresentation(button, petState);
  }
  function applyOverlayUpdate(message) {
    latestMessage = message;
    latestAnimationSpeed = resolveAnimationSpeed(message.payload.animationSpeed);
    const root = ensureRoot();
    root.dataset.hidden = message.payload.scene.visible ? "false" : "true";
    const scene = root.querySelector(".openpet-scene");
    const activeIds = new Set(message.payload.scene.pets.map((pet) => pet.petId));
    scene.querySelectorAll("button.openpet-button").forEach((button) => {
      if (!activeIds.has(button.dataset.petId ?? "")) {
        button.remove();
      }
    });
    message.payload.scene.pets.forEach((petState) => renderPet(scene, petState));
  }

  // packages/adapters/src/deepseek.ts
  function isDeepSeekUrl(url) {
    try {
      return new URL(url).hostname === "chat.deepseek.com";
    } catch {
      return false;
    }
  }
  function detectDeepSeekPage(doc) {
    return isDeepSeekUrl(doc.location.href) && (Boolean(findComposer(doc)) || findAuthSurface(doc));
  }
  function findComposer(doc) {
    return doc.querySelector("textarea, [contenteditable='true'], input[type='text']");
  }
  function findSendButton(doc) {
    const buttons = Array.from(doc.querySelectorAll("button"));
    return buttons.find((button) => {
      const label = [
        button.textContent || "",
        button.getAttribute("aria-label") || "",
        button.getAttribute("title") || ""
      ].join(" ").toLowerCase();
      return label.includes("send") || label.includes("\u53D1\u9001");
    }) || null;
  }
  function isDeepSeekResponseInProgress(doc) {
    return Array.from(doc.querySelectorAll("button")).some((button) => {
      const label = [
        button.textContent || "",
        button.getAttribute("aria-label") || "",
        button.getAttribute("title") || ""
      ].join(" ").toLowerCase();
      return label.includes("stop") || label.includes("\u505C\u6B62") || label.includes("\u4E2D\u6B62");
    });
  }
  function findErrorText(doc) {
    const selectors = ["[role='alert']", "[aria-live='assertive']", "[data-error]", ".error"];
    return selectors.some(
      (selector) => Array.from(doc.querySelectorAll(selector)).some((node) => {
        const text = node.textContent?.toLowerCase() ?? "";
        return text.includes("something went wrong") || text.includes("request failed") || text.includes("\u53D1\u9001\u5931\u8D25") || text.includes("\u8BF7\u6C42\u5931\u8D25") || text.includes("\u9519\u8BEF");
      })
    );
  }
  function findAuthSurface(doc) {
    const bodyText = doc.body.textContent ?? "";
    return bodyText.includes("\u767B\u5F55") || bodyText.includes("\u53D1\u9001\u9A8C\u8BC1\u7801") || bodyText.toLowerCase().includes("password login") || bodyText.includes("\u5FAE\u4FE1\u626B\u7801\u767B\u5F55");
  }
  function collectDeepSeekSignals(doc, previous) {
    const composer = findComposer(doc);
    const sendButton = findSendButton(doc);
    const responseGrowing = Array.from(doc.querySelectorAll("[data-openpet-streaming='true']")).length > 0;
    const settled = Array.from(doc.querySelectorAll("[data-openpet-settled='true']")).length > 0;
    return {
      site: "deepseek",
      composerReady: Boolean(composer),
      sendTriggered: previous?.sendTriggered ?? Boolean(sendButton && sendButton.getAttribute("data-openpet-sent") === "true"),
      responseGrowing,
      errorVisible: findErrorText(doc),
      settled,
      tabActive: doc.visibilityState === "visible",
      timestamp: Date.now()
    };
  }

  // packages/adapters/src/chatgpt.ts
  function isChatGPTUrl(url) {
    try {
      return new URL(url).hostname === "chatgpt.com";
    } catch {
      return false;
    }
  }
  function findChatGPTComposer(doc) {
    return doc.querySelector("#prompt-textarea") ?? doc.querySelector("textarea[placeholder*='Message']") ?? doc.querySelector("textarea") ?? doc.querySelector("[contenteditable='true'][translate='no']") ?? doc.querySelector("[contenteditable='true'][data-lexical-editor='true']");
  }
  function findChatGPTSendButton(doc) {
    const explicitButton = doc.querySelector("button[data-testid*='send']") ?? doc.querySelector("button[aria-label*='Send']");
    if (explicitButton) {
      return explicitButton;
    }
    const buttons = Array.from(doc.querySelectorAll("button"));
    return buttons.find((button) => {
      const label = [
        button.textContent ?? "",
        button.getAttribute("aria-label") ?? "",
        button.getAttribute("title") ?? ""
      ].join(" ").toLowerCase();
      return label.includes("send message") || label.includes("send prompt") || label.includes("send") || label.includes("\u53D1\u9001");
    }) ?? null;
  }
  function isChatGPTResponseInProgress(doc) {
    return Array.from(doc.querySelectorAll("button")).some((button) => {
      const label = [
        button.textContent ?? "",
        button.getAttribute("aria-label") ?? "",
        button.getAttribute("title") ?? "",
        button.getAttribute("data-testid") ?? ""
      ].join(" ").toLowerCase();
      return label.includes("stop generating") || label.includes("stop") || label.includes("abort");
    });
  }
  function findChatGPTErrorText(doc) {
    const selectors = ["[role='alert']", "[aria-live='assertive']", ".text-red-500", ".text-danger"];
    return selectors.some(
      (selector) => Array.from(doc.querySelectorAll(selector)).some((node) => {
        const text = node.textContent?.toLowerCase() ?? "";
        return text.includes("something went wrong") || text.includes("an error occurred") || text.includes("network error") || text.includes("\u51FA\u4E86\u70B9\u95EE\u9898");
      })
    );
  }
  function findChatGPTAuthSurface(doc) {
    const bodyText = doc.body.textContent?.toLowerCase() ?? "";
    return bodyText.includes("log in") || bodyText.includes("sign up") || bodyText.includes("continue with google") || bodyText.includes("welcome back") || bodyText.includes("\u767B\u5F55") || bodyText.includes("\u6CE8\u518C");
  }
  function detectChatGPTPage(doc) {
    const bodyText = doc.body.textContent?.toLowerCase() ?? "";
    return isChatGPTUrl(doc.location.href) && (Boolean(findChatGPTComposer(doc)) || Boolean(findChatGPTSendButton(doc)) || findChatGPTAuthSurface(doc) || bodyText.includes("chatgpt") || bodyText.includes("what\u2019s on the agenda today?") || bodyText.includes("what's on the agenda today?"));
  }
  function collectChatGPTSignals(doc, previous) {
    return {
      site: "chatgpt",
      composerReady: Boolean(findChatGPTComposer(doc)),
      sendTriggered: previous?.sendTriggered ?? false,
      responseGrowing: Array.from(doc.querySelectorAll("[data-openpet-streaming='true']")).length > 0,
      errorVisible: findChatGPTErrorText(doc),
      settled: Array.from(doc.querySelectorAll("[data-openpet-settled='true']")).length > 0,
      tabActive: doc.visibilityState === "visible",
      timestamp: Date.now()
    };
  }

  // packages/adapters/src/doubao.ts
  function isDoubaoUrl(url) {
    try {
      const { hostname, pathname } = new URL(url);
      const isDoubaoHost = hostname === "www.doubao.com" || hostname === "doubao.com";
      return isDoubaoHost && (pathname === "/chat" || pathname === "/chat/" || pathname.startsWith("/chat/"));
    } catch {
      return false;
    }
  }
  function findDoubaoComposer(doc) {
    return doc.querySelector("textarea[placeholder='\u53D1\u6D88\u606F...']") ?? doc.querySelector("textarea") ?? doc.querySelector("[contenteditable='true']") ?? doc.querySelector("input[type='text']") ?? doc.querySelector("input[placeholder*='\u8C46\u5305']") ?? doc.querySelector("textarea[placeholder*='\u8C46\u5305']");
  }
  function findDoubaoSendButton(doc) {
    const explicitButton = doc.querySelector("button[class*='send-msg-btn']") ?? doc.querySelector("button[data-testid*='send']");
    if (explicitButton) {
      return explicitButton;
    }
    const buttons = Array.from(doc.querySelectorAll("button"));
    return buttons.find((button) => {
      const label = [
        button.textContent ?? "",
        button.getAttribute("aria-label") ?? "",
        button.getAttribute("title") ?? ""
      ].join(" ").toLowerCase();
      return label.includes("\u53D1\u9001") || label.includes("send") || label.includes("\u63D0\u4EA4") || label.includes("continue");
    }) ?? null;
  }
  function isDoubaoResponseInProgress(doc) {
    return Array.from(doc.querySelectorAll("button")).some((button) => {
      const label = [
        button.textContent ?? "",
        button.getAttribute("aria-label") ?? "",
        button.getAttribute("title") ?? "",
        button.getAttribute("class") ?? ""
      ].join(" ").toLowerCase();
      return label.includes("stop") || label.includes("\u505C\u6B62\u751F\u6210") || label.includes("\u505C\u6B62\u56DE\u590D") || label.includes("\u7ED3\u675F\u751F\u6210") || label.includes("\u751F\u6210\u4E2D") || label.includes("\u6B63\u5728\u751F\u6210") || label.includes("\u505C\u6B62") || label.includes("\u4E2D\u6B62") || label.includes("generating") || label.includes("loading") || label.includes("processing");
    });
  }
  function findDoubaoErrorText(doc) {
    const bodyText = doc.body.textContent?.toLowerCase() ?? "";
    return bodyText.includes("\u8BE5\u9875\u9762\u6682\u65F6\u4E0D\u53EF\u7528") || bodyText.includes("\u6280\u672F\u9519\u8BEF") || bodyText.includes("unexpected application error") || bodyText.includes("\u6682\u65F6\u4E0D\u53EF\u7528");
  }
  function findDoubaoAuthSurface(doc) {
    const bodyText = doc.body.textContent?.toLowerCase() ?? "";
    return bodyText.includes("\u53D7\u533A\u57DF\u9650\u5236") || bodyText.includes("\u8BF7\u5148\u767B\u5F55\u518D\u4F7F\u7528\u8C46\u5305") || bodyText.includes("\u4F7F\u7528 dola\u767B\u5F55") || bodyText.includes("\u767B\u5F55") || bodyText.includes("\u4E0B\u8F7D\u7535\u8111\u7248") || bodyText.includes("\u5185\u5BB9\u7531\u8C46\u5305 ai \u751F\u6210") || bodyText.includes("\u624B\u673A\u53F7\u767B\u5F55");
  }
  function detectDoubaoPage(doc) {
    return isDoubaoUrl(doc.location.href) && (Boolean(findDoubaoComposer(doc)) || Boolean(findDoubaoSendButton(doc)) || findDoubaoAuthSurface(doc));
  }
  function collectDoubaoSignals(doc, previous) {
    const responseGrowing = Array.from(doc.querySelectorAll("[data-openpet-streaming='true']")).length > 0;
    return {
      site: "doubao",
      composerReady: Boolean(findDoubaoComposer(doc)),
      sendTriggered: previous?.sendTriggered ?? false,
      responseGrowing,
      errorVisible: findDoubaoErrorText(doc),
      settled: Array.from(doc.querySelectorAll("[data-openpet-settled='true']")).length > 0 && !responseGrowing && !isDoubaoResponseInProgress(doc),
      tabActive: doc.visibilityState === "visible",
      timestamp: Date.now()
    };
  }

  // packages/adapters/src/gemini.ts
  function isGeminiUrl(url) {
    try {
      return new URL(url).hostname === "gemini.google.com";
    } catch {
      return false;
    }
  }
  function findGeminiComposer(doc) {
    return doc.querySelector("[contenteditable='true']") ?? doc.querySelector("textarea") ?? doc.querySelector("input[type='text']");
  }
  function findGeminiSendButton(doc) {
    const buttons = Array.from(doc.querySelectorAll("button"));
    return buttons.find((button) => {
      const label = [
        button.textContent ?? "",
        button.getAttribute("aria-label") ?? "",
        button.getAttribute("title") ?? ""
      ].join(" ").toLowerCase();
      return label.includes("send") || label.includes("submit") || label.includes("\u53D1\u9001");
    }) ?? null;
  }
  function isGeminiResponseInProgress(doc) {
    return Array.from(doc.querySelectorAll("button")).some((button) => {
      const label = [
        button.textContent ?? "",
        button.getAttribute("aria-label") ?? "",
        button.getAttribute("title") ?? ""
      ].join(" ").toLowerCase();
      return label.includes("stop") || label.includes("\u505C\u6B62") || label.includes("cancel") || label.includes("generating");
    });
  }
  function findGeminiErrorText(doc) {
    const alertSelectors = [
      "[role='alert']",
      "[aria-live='assertive']",
      "[data-error]",
      ".error"
    ];
    return alertSelectors.some(
      (selector) => Array.from(doc.querySelectorAll(selector)).some((node) => {
        const text = node.textContent?.toLowerCase() ?? "";
        return text.includes("something went wrong") || text.includes("try again");
      })
    );
  }
  function findGeminiAuthSurface(doc) {
    const bodyText = doc.body.textContent?.toLowerCase() ?? "";
    return bodyText.includes("sign in") || bodyText.includes("\u767B\u5F55");
  }
  function detectGeminiPage(doc) {
    return isGeminiUrl(doc.location.href) && (Boolean(findGeminiComposer(doc)) || Boolean(findGeminiSendButton(doc)) || findGeminiAuthSurface(doc) || doc.body.textContent?.toLowerCase().includes("gemini") === true);
  }
  function collectGeminiSignals(doc, previous) {
    return {
      site: "gemini",
      composerReady: Boolean(findGeminiComposer(doc)),
      sendTriggered: previous?.sendTriggered ?? false,
      responseGrowing: Array.from(doc.querySelectorAll("[data-openpet-streaming='true']")).length > 0,
      errorVisible: findGeminiErrorText(doc),
      settled: Array.from(doc.querySelectorAll("[data-openpet-settled='true']")).length > 0,
      tabActive: doc.visibilityState === "visible",
      timestamp: Date.now()
    };
  }

  // packages/adapters/src/index.ts
  var siteAdapters = [
    {
      siteId: "deepseek",
      matches: isDeepSeekUrl,
      detectPage: detectDeepSeekPage,
      getObservationRoot: (doc) => doc,
      getResponseRoot: (doc) => doc.querySelector("main") ?? doc.body ?? doc,
      findComposer,
      findSendButton,
      isResponseInProgress: isDeepSeekResponseInProgress,
      collectSignals: collectDeepSeekSignals
    },
    {
      siteId: "gemini",
      matches: isGeminiUrl,
      detectPage: detectGeminiPage,
      getObservationRoot: (doc) => doc,
      getResponseRoot: (doc) => doc.querySelector("main") ?? doc.body ?? doc,
      findComposer: findGeminiComposer,
      findSendButton: findGeminiSendButton,
      isResponseInProgress: isGeminiResponseInProgress,
      collectSignals: collectGeminiSignals
    },
    {
      siteId: "chatgpt",
      matches: isChatGPTUrl,
      detectPage: detectChatGPTPage,
      getObservationRoot: (doc) => doc.querySelector("main") ?? doc,
      getResponseRoot: (doc) => doc.querySelector("main") ?? doc.body ?? doc,
      findComposer: findChatGPTComposer,
      findSendButton: findChatGPTSendButton,
      isResponseInProgress: isChatGPTResponseInProgress,
      collectSignals: collectChatGPTSignals
    },
    {
      siteId: "doubao",
      matches: isDoubaoUrl,
      detectPage: detectDoubaoPage,
      getObservationRoot: (doc) => doc.querySelector("main") ?? doc,
      getResponseRoot: (doc) => doc.querySelector("main") ?? doc.body ?? doc,
      findComposer: findDoubaoComposer,
      findSendButton: findDoubaoSendButton,
      isResponseInProgress: isDoubaoResponseInProgress,
      collectSignals: collectDoubaoSignals
    }
  ];
  function getAdapterForUrl(url) {
    return siteAdapters.find((adapter) => adapter.matches(url)) ?? null;
  }

  // apps/chrome-extension/src/content/main.ts
  function createRuntimeTracker() {
    return {
      sendTriggeredAt: null,
      lastRelevantMutationAt: null,
      settleTimer: null,
      idleResetTimer: null,
      cycleSettled: false,
      cooldownUntil: 0
    };
  }
  function openSendCycle(runtime) {
    if (runtime.sendTriggeredAt !== null) {
      return;
    }
    runtime.sendTriggeredAt = Date.now();
    runtime.lastRelevantMutationAt = null;
    runtime.cycleSettled = false;
    runtime.cooldownUntil = 0;
  }
  function clearScheduledTransitions(runtime, view) {
    if (runtime.settleTimer !== null) {
      view.clearTimeout(runtime.settleTimer);
      runtime.settleTimer = null;
    }
    if (runtime.idleResetTimer !== null) {
      view.clearTimeout(runtime.idleResetTimer);
      runtime.idleResetTimer = null;
    }
  }
  function isElementTarget(doc, target) {
    const ElementCtor = doc.defaultView?.Element ?? Element;
    return target instanceof ElementCtor;
  }
  function isComposerTarget(adapter, doc, target) {
    if (!isElementTarget(doc, target)) {
      return false;
    }
    const composer = adapter.findComposer(doc);
    return Boolean(composer && (target === composer || composer.contains(target)));
  }
  function isSendTriggerTarget(adapter, doc, target) {
    if (!isElementTarget(doc, target)) {
      return false;
    }
    const button = target.closest("button");
    return Boolean(button && button === adapter.findSendButton(doc));
  }
  function publishSignals(doc = document, adapter, runtime = createRuntimeTracker()) {
    const baseSignals = adapter.collectSignals(doc, { sendTriggered: runtime.sendTriggeredAt !== null });
    const now = Date.now();
    const lastRelevantMutationAt = runtime.lastRelevantMutationAt;
    const responseInProgress = runtime.sendTriggeredAt !== null && (adapter.isResponseInProgress?.(doc) ?? false);
    const responseGrowing = runtime.sendTriggeredAt !== null && lastRelevantMutationAt !== null && (lastRelevantMutationAt === null || now - lastRelevantMutationAt < 1500);
    const settled = runtime.sendTriggeredAt !== null && !responseInProgress && lastRelevantMutationAt !== null && now - lastRelevantMutationAt >= 1500;
    const signals = {
      ...baseSignals,
      sendTriggered: runtime.sendTriggeredAt !== null,
      responseGrowing,
      settled
    };
    if (signals.settled) {
      runtime.cycleSettled = true;
    }
    console.debug("[openpet-content] publishSignals", JSON.stringify(signals));
    const message = {
      type: messageTypes.pageSignals,
      payload: signals
    };
    void chrome.runtime.sendMessage(message);
  }
  function handleContentMessage(message) {
    if (message.type === messageTypes.sceneUpdate) {
      console.debug(
        "[openpet-content] sceneUpdate",
        JSON.stringify({
          visible: message.payload.visible,
          pets: message.payload.scene.pets.map((pet) => ({
            id: pet.pet.id,
            siteId: pet.siteId,
            state: pet.state
          }))
        })
      );
      applyOverlayUpdate(message);
    }
  }
  async function requestCurrentDisplayState() {
    const response = await chrome.runtime.sendMessage({
      type: messageTypes.currentSceneState
    });
    if (response?.type === messageTypes.sceneUpdate) {
      handleContentMessage(response);
    }
  }
  function bootstrapContentScript(doc = document) {
    const runtime = createRuntimeTracker();
    const view = doc.defaultView ?? window;
    const adapter = getAdapterForUrl(doc.location.href);
    const observationRoot = adapter?.getObservationRoot?.(doc) ?? doc.documentElement;
    const responseRoot = adapter?.getResponseRoot?.(doc) ?? observationRoot;
    chrome.runtime.onMessage.addListener((message) => {
      handleContentMessage(message);
    });
    if (adapter && doc.readyState === "loading") {
      doc.addEventListener("DOMContentLoaded", () => publishSignals(doc, adapter, runtime), { once: true });
    } else if (adapter) {
      publishSignals(doc, adapter, runtime);
    } else {
      void requestCurrentDisplayState();
      return new MutationObserver(() => void 0);
    }
    let publishQueued = false;
    const queuePublish = () => {
      if (publishQueued) {
        return;
      }
      publishQueued = true;
      queueMicrotask(() => {
        publishQueued = false;
        publishSignals(doc, adapter, runtime);
      });
    };
    const scheduleStateTransitions = () => {
      clearScheduledTransitions(runtime, view);
      if (runtime.sendTriggeredAt === null) {
        return;
      }
      runtime.settleTimer = view.setTimeout(() => {
        queuePublish();
      }, 1600);
      runtime.idleResetTimer = view.setTimeout(() => {
        if (runtime.sendTriggeredAt === null || (adapter.isResponseInProgress?.(doc) ?? false) || runtime.lastRelevantMutationAt === null) {
          return;
        }
        if (Date.now() - runtime.lastRelevantMutationAt < 1500) {
          return;
        }
        runtime.sendTriggeredAt = null;
        runtime.lastRelevantMutationAt = null;
        runtime.cycleSettled = false;
        runtime.cooldownUntil = Date.now() + 1500;
        queuePublish();
      }, 2800);
    };
    doc.addEventListener(
      "click",
      (event) => {
        if (isSendTriggerTarget(adapter, doc, event.target)) {
          openSendCycle(runtime);
          scheduleStateTransitions();
          queuePublish();
        }
      },
      true
    );
    doc.addEventListener(
      "keydown",
      (event) => {
        if (event.key === "Enter" && !event.shiftKey && isComposerTarget(adapter, doc, event.target)) {
          openSendCycle(runtime);
          scheduleStateTransitions();
          queuePublish();
        }
      },
      true
    );
    doc.addEventListener(
      "input",
      (event) => {
        if (adapter && isComposerTarget(adapter, doc, event.target) && runtime.sendTriggeredAt !== null && runtime.lastRelevantMutationAt === null) {
          runtime.sendTriggeredAt = null;
          clearScheduledTransitions(runtime, view);
          queuePublish();
        }
      },
      true
    );
    const observer = new MutationObserver((mutations) => {
      const hasRelevantMutation = mutations.some((mutation) => {
        const targetNode = isElementTarget(doc, mutation.target) ? mutation.target : mutation.target.parentElement;
        return !targetNode?.closest?.(`#${overlayRootId}`);
      });
      if (!hasRelevantMutation) {
        return;
      }
      const hasResponseMutation = mutations.some((mutation) => {
        const targetNode = isElementTarget(doc, mutation.target) ? mutation.target : mutation.target.parentElement;
        if (!targetNode || targetNode.closest?.(`#${overlayRootId}`)) {
          return false;
        }
        if (responseRoot instanceof Document) {
          return true;
        }
        return targetNode === responseRoot || responseRoot.contains(targetNode);
      });
      if (runtime.sendTriggeredAt === null && (adapter.isResponseInProgress?.(doc) ?? false)) {
        openSendCycle(runtime);
        scheduleStateTransitions();
      }
      if (runtime.sendTriggeredAt !== null && !runtime.cycleSettled && hasResponseMutation) {
        runtime.lastRelevantMutationAt = Date.now();
        scheduleStateTransitions();
      }
      queuePublish();
    });
    observer.observe(observationRoot, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ["class", "aria-label", "title", "disabled", "data-testid"],
      characterData: false
    });
    return observer;
  }
  if (typeof chrome !== "undefined" && chrome.runtime?.onMessage) {
    bootstrapContentScript();
  }
})();
//# sourceMappingURL=content.js.map
